#!/bin/bash
grep -i POST access.log  | grep -i 404
