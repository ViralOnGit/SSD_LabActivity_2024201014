QUES:1:for the first question(q1), I have used grep command with ignore condition, to get both conditions intake i have used | command to check both conditions.
QUES:2:for the second question(q2), I have used awk command giving column 4 in input condition with sum, which sums up all the values of column 4.



